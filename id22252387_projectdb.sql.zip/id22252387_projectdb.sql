-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 01, 2024 at 09:07 PM
-- Server version: 10.5.20-MariaDB
-- PHP Version: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id22252387_projectdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `About`
--

CREATE TABLE `About` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `About`
--

INSERT INTO `About` (`id`, `title`, `content`, `image_url`) VALUES
(1, 'Welcome to Betty\'s A Bakery & Coffee Shop', 'We serve you your desired pastry with the taste of drinks.\r\n    Twin glasses of orange juice, froth quietly fizzling out. \r\n    A plate of fresh fruits piled overzealously high.\r\n    We would cook you French toast every day, if you\'d ask for.\r\n    Fresh croissants from a bakery down the street.\r\n    Halved strawberries drizzled with honey.\r\n    We\'ll sprinkle cinnamon in your coffee, just like my grandmother used to.\r\n    We don\'t know much of love, but we know this:\r\n    \"When the sun breaks through the kitchen window, \r\n    We hope you\'ll be sitting at our table enjoying our pastry.\"', 'Bakery12.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `ContactUs`
--

CREATE TABLE `ContactUs` (
  `id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `comment` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ContactUs`
--

INSERT INTO `ContactUs` (`id`, `first_name`, `last_name`, `email`, `comment`) VALUES
(1, 'b', 's', 's@a', 's'),
(2, 'ss', 'aa', 'aaa@sss', 'a'),
(3, 's', 'sss', 'a@w', 'sss'),
(4, 'aa', 'aaa', 'a@aa', 'aa'),
(5, 'aa', 'aa', 'a#@aa', 'aa'),
(6, 'aa', 'aa', 'a#@aa', 'aa'),
(7, 'aa', 'aa', 'a@aa', 'aa'),
(8, 'zz', 'zz', 'zz@s', 'zz'),
(9, 'zz', 'zz', 'zz@s', 'zz'),
(10, 'aa', 'aa', 'a@aa', 'aa'),
(11, 'bb', 'n', 'n@s', 'j'),
(12, 'batoul', 'noureddine', 'batoul@csci', 'comment'),
(13, 'test', 'test', 'test@test', 'test'),
(14, 'Batoul ', 'Noureddine ', 'batoul@students.liu.lb', 'Wow'),
(15, 'Batata', 'Maslo2a', 'batata@potato', 'La batata'),
(16, 'b', 'n', 'g@d', 'n');

-- --------------------------------------------------------

--
-- Table structure for table `Home`
--

CREATE TABLE `Home` (
  `image_id` int(11) NOT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `overall_menu_description` text DEFAULT NULL,
  `experience_description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Home`
--

INSERT INTO `Home` (`image_id`, `image_url`, `description`, `overall_menu_description`, `experience_description`) VALUES
(1, 'slide1.jpg', 'All Kinds of Bread', NULL, NULL),
(2, 'slide2.jpg', 'Quick Service', NULL, NULL),
(3, 'slide3.jpg', 'Delicious Petit Four', NULL, NULL),
(4, 'slide14.jpg', 'Made with the Fluffiest Dough', NULL, NULL),
(5, 'slide6.jpg', 'The Best Smoothies', NULL, NULL),
(6, 'slide8.jpg', 'Cozy Atmosphere', NULL, NULL),
(7, 'slide5.jpg', 'Cappuccino Made with Love', NULL, NULL),
(8, 'slide4.jpg', 'All Kinds of Cold Desserts', NULL, NULL),
(9, 'slide7.jpg', 'All Kinds of Cakes', NULL, NULL),
(10, 'slide11.jpg', 'Blueberry Pastry', NULL, NULL),
(11, 'slide10.jpg', 'Tasty Pastries', NULL, NULL),
(12, 'slide9.jpg', 'Doughnuts & more', NULL, NULL),
(13, 'slide17.jpg', 'The Best Espresso', NULL, NULL),
(14, 'slide13.jpg', 'Coffee & some comfort', NULL, NULL),
(15, 'slide12.jpg', 'Organized & well baked', NULL, NULL),
(16, 'slide18.jpg', 'Our Pleasant Customers', NULL, NULL),
(17, 'slide15.jpg', 'Special Plates made with passion', NULL, NULL),
(18, 'alide18.jpg', 'Latte', NULL, NULL),
(19, NULL, NULL, 'We Serve All Kinds Of Pastry & Coffee! Bread, Rolls, Cookies, Pies, Pastries, Muffins, Bagels, Buns, Desserts, Cakes, Cheesecakes, Pies, Doughnuts, Danish, Sweet Rolls, Cinnamon Rolls, Coffee Cake, Brownies, Blueberry Cupcakes, Latte, Cappuccino, Americano, Espresso, Cortado, Mocha, Macchiato, Iced Coffee, Cafe Au Lait...', 'We provide you with the best experience including: Free Wi-Fi and charging options. Hosting special events every vocation. Classic music which is always there to secure your comfort and satisfaction. A neat and well-maintained salon colored with harmonious hue. A salon designed with cozy furniture to satisfy you.');

-- --------------------------------------------------------

--
-- Table structure for table `Menu`
--

CREATE TABLE `Menu` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(5,2) NOT NULL,
  `image_url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Menu`
--

INSERT INTO `Menu` (`id`, `name`, `description`, `price`, `image_url`) VALUES
(1, 'Pastry', 'Baklava. Puff Pastry. Danish Pastry. Cannoli. Éclair. Tiramisu.', 2.90, 'pastry02.jpg'),
(2, 'Smoothies', 'Strawberry, Bannana, Mango, Caramel, Latte, Chocolate, Vanilla', 2.90, 'smoothies1.jpeg'),
(3, 'Cappuccino', 'A cappuccino is the perfect balance of espresso, steamed milk and foam.', 2.90, 'cappuccino01.jpg'),
(4, 'Petit Four', 'petits fours salé, petits fours sec, petits fours frais', 2.90, 'petitfour05.jpg'),
(5, 'Donuts', 'Chocolate, Vanilla, Lutos, Caramel', 2.90, 'donuts02.jpg'),
(6, 'Espresso', 'A good cup of coffee is like the perfect piece of art', 2.90, 'espresso01.jpg'),
(7, 'Latte Macchiato', 'Latte art is a love language.', 2.90, 'lattemacchiato03.webp'),
(8, 'Cheese Cake', 'Strawberry, Lutos, Blueberry, Caramel,..', 2.90, 'Cheesecakes01.jpg'),
(9, 'Muffin', 'Life is better with sprinkles and muffins.', 2.90, 'muffin01.jpg'),
(10, 'Hot Chocolate with Whipped Cream', 'The perfect blend of cocoa and comfort.', 2.90, 'Hotchocolate01.jpg'),
(11, 'Cinnamon Rolls', 'Raseberry Cinnamon Rolls, Chocolate Cinamon Rolles, Blueberry Cinnamon Rolls', 2.90, 'Raspberrycinnamonroll01.jpg'),
(12, 'French Croissant', 'Chocolate, Cheese, Lutos, Caramel,..', 2.90, 'Bakery012.jpg'),
(13, 'Cake', 'Chocolate, Vanilla, Strawberry, Blueberry, Pineapple,..', 2.90, 'cake03.jpg'),
(14, 'Iced Coffee', 'There\'s no problem an iced coffee can\'t solve!', 2.90, 'Iced Coffee01.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `RateUs`
--

CREATE TABLE `RateUs` (
  `rate_id` int(11) NOT NULL,
  `overall_rating` int(11) NOT NULL,
  `taste_rating` int(11) NOT NULL,
  `bake_rating` int(11) NOT NULL,
  `experience_rating` int(11) NOT NULL,
  `service_rating` int(11) NOT NULL,
  `review_text` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `About`
--
ALTER TABLE `About`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ContactUs`
--
ALTER TABLE `ContactUs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Home`
--
ALTER TABLE `Home`
  ADD PRIMARY KEY (`image_id`);

--
-- Indexes for table `Menu`
--
ALTER TABLE `Menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `RateUs`
--
ALTER TABLE `RateUs`
  ADD PRIMARY KEY (`rate_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `About`
--
ALTER TABLE `About`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ContactUs`
--
ALTER TABLE `ContactUs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `Home`
--
ALTER TABLE `Home`
  MODIFY `image_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `Menu`
--
ALTER TABLE `Menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `RateUs`
--
ALTER TABLE `RateUs`
  MODIFY `rate_id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
